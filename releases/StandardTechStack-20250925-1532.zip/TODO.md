# TODO

- Recursos visuales
- Aplicación de referencia Front
- Aplicación de referencia Back
- Despliegue de aplicaciones
- Flujo de revisión de desarrollos hechos por terceros
